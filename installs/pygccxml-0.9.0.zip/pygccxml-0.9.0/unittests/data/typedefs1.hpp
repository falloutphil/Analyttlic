// Copyright 2004 Roman Yakovenko.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef __typedefs1_hpp__
#define __typedefs1_hpp__

#include "typedefs_base.hpp"

namespace typedefs{

typedef item_t Item1;

}

#endif//__typedefs1_hpp__